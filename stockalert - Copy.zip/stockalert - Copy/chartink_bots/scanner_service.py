import threading
import asyncio
import time
import logging
from datetime import datetime
from django.utils import timezone
from .models import Bot, Scanner
from .services import ChartinkService
from asgiref.sync import sync_to_async

logger = logging.getLogger(__name__)

class ScannerThread(threading.Thread):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._stop_event = threading.Event()
        self.daemon = True

    def stop(self):
        self._stop_event.set()

    def stopped(self):
        return self._stop_event.is_set()

    async def should_run_scanner(self, scanner):
        """Check if scanner should be run based on its last run time"""
        if not scanner.last_run:
            return True
        
        now = timezone.now()
        time_since_last_run = (now - scanner.last_run).total_seconds()
        return time_since_last_run >= scanner.scan_interval

    async def process_scanner(self, bot, scanner):
        """Process a single scanner with proper async handling"""
        try:
            service = ChartinkService(bot)
            result = await service.process_scanner(scanner)
            
            if result is True:
                # Update last run time using sync_to_async
                scanner.last_run = timezone.now()
                await sync_to_async(scanner.save)(update_fields=['last_run'])
                
        except Exception as e:
            logger.error(f"Error processing scanner {scanner.name}: {str(e)}")

    async def run_async(self):
        """Async version of the main scanning loop"""
        while not self.stopped():
            try:
                # Get all active bots and their scanners using sync_to_async
                get_bots = sync_to_async(lambda: list(Bot.objects.filter(is_active=True).prefetch_related('scanners')))
                bots = await get_bots()
                
                for bot in bots:
                    # Get active scanners using sync_to_async
                    get_scanners = sync_to_async(lambda b=bot: list(b.scanners.filter(is_active=True)))
                    active_scanners = await get_scanners()
                    
                    for scanner in active_scanners:
                        # Check if it's time to run this scanner
                        should_run = await self.should_run_scanner(scanner)
                        if should_run:
                            await self.process_scanner(bot, scanner)
                
            except Exception as e:
                logger.error(f"Error in scanner thread: {str(e)}")
            
            # Sleep for a short interval before next check
            await asyncio.sleep(10)  # Check every 10 seconds

    def run(self):
        """Main thread entry point"""
        while not self.stopped():
            try:
                # Create event loop for async operations
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                # Run the async loop
                loop.run_until_complete(self.run_async())
                
            except Exception as e:
                logger.error(f"Error in scanner thread main loop: {str(e)}")
            finally:
                loop.close()
            
            # If we get here, something went wrong with the loop
            # Wait a bit before recreating it
            time.sleep(5)

# Global scanner thread instance
_scanner_thread = None

def start_scanner_thread():
    """Start the scanner thread if it's not already running"""
    global _scanner_thread
    if _scanner_thread is None or not _scanner_thread.is_alive():
        _scanner_thread = ScannerThread()
        _scanner_thread.start()
        logger.info("Scanner thread started")

def stop_scanner_thread():
    """Stop the scanner thread"""
    global _scanner_thread
    if _scanner_thread and _scanner_thread.is_alive():
        _scanner_thread.stop()
        _scanner_thread.join()
        _scanner_thread = None
        logger.info("Scanner thread stopped") 