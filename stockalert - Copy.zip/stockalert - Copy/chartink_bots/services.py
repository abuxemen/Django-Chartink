import json
import logging
import aiohttp
import requests
from bs4 import BeautifulSoup
from telegram import Bot as TelegramBot
from telegram.error import TelegramError
from datetime import datetime
import pytz
from .models import Bot, Scanner, ScanResult
from asgiref.sync import sync_to_async
from django.utils import timezone
from functools import partial
import time

logger = logging.getLogger(__name__)

class ChartinkService:
    def __init__(self, bot: Bot):
        self.bot = bot
        self.telegram_bot = TelegramBot(token=bot.token)
        
    async def get_data_from_chartink(self, condition):
        """Fetch data from ChartInk asynchronously"""
        try:
            url = "https://chartink.com/screener/process"
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'X-Requested-With': 'XMLHttpRequest',
                'Origin': 'https://chartink.com',
                'Referer': 'https://chartink.com/screener',
            }

            async with aiohttp.ClientSession() as session:
                # First, get the CSRF token and cookies
                async with session.get('https://chartink.com/screener', headers=headers) as response:
                    text = await response.text()
                    soup = BeautifulSoup(text, 'html.parser')
                    csrf_token = soup.find('meta', {'name': 'csrf-token'})['content']
                
                # Add CSRF token to headers
                headers['X-CSRF-TOKEN'] = csrf_token
                
                # Send the request with URL-encoded form data
                form_data = {'scan_clause': condition}
                async with session.post(url, data=form_data, headers=headers) as response:
                    if response.status != 200:
                        logger.error(f"ChartInk API returned status code {response.status}")
                        return None
                    
                    # Get the response text and try to parse it as JSON regardless of content type
                    response_text = await response.text()
                    try:
                        result = json.loads(response_text)
                        if 'data' in result:
                            logger.info(f"Successfully fetched {len(result['data'])} stocks from ChartInk")
                            return result
                        else:
                            logger.error("Response missing 'data' field")
                            logger.error(f"Response content: {response_text[:200]}...")
                            return None
                    except json.JSONDecodeError as e:
                        logger.error(f"Failed to parse JSON response: {str(e)}")
                        logger.error(f"Response content: {response_text[:200]}...")
                        return None
                    
        except Exception as e:
            logger.error(f"Error fetching data from ChartInk: {str(e)}")
            return None

    def format_scan_results(self, scan_name, data, is_new=False):
        """Format scan results for telegram message"""
        indian_tz = pytz.timezone('Asia/Kolkata')
        current_date = datetime.now(indian_tz).strftime("%d-%m-%Y")
        current_time = datetime.now(indian_tz).strftime("%I:%M:%S %p")
        
        response = f"💎 *{scan_name}* {'🆕' if is_new else '🔍'}\n"
        response += "-----------------------------------\n"
        response += f"🗓 {current_date}\n"
        response += f"🕙 {current_time}\n"
        response += f"🔮 *[{len(data)}]*\n"
        response += "-----------------------------------\n"
        
        # Format each stock in table format
        for item in data:
            # Format price and volume with proper alignment
            price = f"₹{item['close']:,.2f}"
            volume = f"{item['volume']:,}"
            # Make stock symbol copyable by wrapping in backticks
            response += f"`{item['nsecode']}` | {price} | {volume}\n"
            
        return response

    async def process_scanner(self, scanner: Scanner):
        """Process a single scanner"""
        start_time = time.time()
        error_message = None
        
        try:
            result = await self.get_data_from_chartink(scanner.condition)
            if result and 'data' in result:
                # Get previous results using sync_to_async
                get_previous = sync_to_async(
                    lambda: ScanResult.objects.filter(scanner=scanner).order_by('-created_at').first()
                )
                previous_result = await get_previous()
                
                current_stocks = {item['nsecode'] for item in result['data']}
                previous_stocks = set()
                if previous_result:
                    previous_stocks = {stock['nsecode'] for stock in previous_result.stocks.get('data', [])}

                # Find new stocks
                new_stocks = current_stocks - previous_stocks
                new_stocks_data = [item for item in result['data'] if item['nsecode'] in new_stocks]
                
                message_sent = False
                if new_stocks:
                    # Format response with only new stocks
                    response = self.format_scan_results(scanner.name, new_stocks_data, is_new=True)
                    await self.telegram_bot.send_message(
                        chat_id=scanner.chat_id, 
                        text=response,
                        parse_mode='Markdown'
                    )
                    message_sent = True
                
                # Calculate scan duration
                scan_duration = time.time() - start_time
                
                # Save current results using sync_to_async
                create_result = sync_to_async(
                    lambda: ScanResult.objects.create(
                        scanner=scanner,
                        stocks=result,
                        total_stocks=len(result['data']),
                        new_stocks=new_stocks_data if new_stocks else None,
                        total_new_stocks=len(new_stocks),
                        message_sent=message_sent,
                        scan_duration=scan_duration,
                        error_message=error_message
                    )
                )
                await create_result()
                
                # Update scanner's last_run time
                scanner.last_run = timezone.now()
                await sync_to_async(scanner.save)(update_fields=['last_run'])
                
                return True
                
        except TelegramError as e:
            error_message = f"Telegram error: {str(e)}"
            logger.error(f"Telegram error for scanner {scanner.name}: {str(e)}")
        except Exception as e:
            error_message = str(e)
            logger.error(f"Error processing scanner {scanner.name}: {str(e)}")
        
        if error_message:
            # Save error result
            create_error_result = sync_to_async(
                lambda: ScanResult.objects.create(
                    scanner=scanner,
                    stocks={'data': []},
                    total_stocks=0,
                    total_new_stocks=0,
                    message_sent=False,
                    scan_duration=time.time() - start_time,
                    error_message=error_message
                )
            )
            await create_error_result()
            
        return error_message

    async def process_all_scanners(self):
        """Process all active scanners for this bot"""
        get_scanners = sync_to_async(
            lambda: list(Scanner.objects.filter(bot=self.bot, is_active=True))
        )
        active_scanners = await get_scanners()
        
        for scanner in active_scanners:
            await self.process_scanner(scanner) 