from django.contrib import admin
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from .models import Bot, Scanner, ScanResult

class BotResource(resources.ModelResource):
    class Meta:
        model = Bot
        fields = ('id', 'name', 'token', 'chat_id', 'owner', 'is_active', 'created_at', 'updated_at')
        export_order = ('id', 'name', 'owner', 'is_active', 'chat_id', 'created_at', 'updated_at')

class ScannerResource(resources.ModelResource):
    class Meta:
        model = Scanner
        fields = ('id', 'name', 'condition', 'bot', 'chat_id', 'is_active', 'scan_interval', 'last_run', 'created_at', 'updated_at')
        export_order = ('id', 'name', 'bot', 'is_active', 'scan_interval', 'chat_id', 'last_run', 'created_at', 'updated_at')

class ScanResultResource(resources.ModelResource):
    class Meta:
        model = ScanResult
        fields = ('id', 'scanner', 'total_stocks', 'total_new_stocks', 'message_sent', 'scan_duration', 'created_at')
        export_order = ('id', 'scanner', 'total_stocks', 'total_new_stocks', 'message_sent', 'scan_duration', 'created_at')

@admin.register(Bot)
class BotAdmin(ImportExportModelAdmin):
    resource_class = BotResource
    list_display = ('name', 'owner', 'is_active', 'created_at', 'updated_at')
    list_filter = ('is_active', 'created_at', 'owner')
    search_fields = ('name', 'owner__username', 'chat_id')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'owner', 'is_active')
        }),
        ('Telegram Configuration', {
            'fields': ('token', 'chat_id')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Scanner)
class ScannerAdmin(ImportExportModelAdmin):
    resource_class = ScannerResource
    list_display = ('name', 'bot', 'is_active', 'scan_interval', 'last_run', 'created_at')
    list_filter = ('is_active', 'created_at', 'bot', 'scan_interval')
    search_fields = ('name', 'condition', 'bot__name', 'chat_id')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at', 'last_run')
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'bot', 'is_active')
        }),
        ('Scanner Configuration', {
            'fields': ('condition', 'chat_id', 'scan_interval')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at', 'last_run'),
            'classes': ('collapse',)
        }),
    )

@admin.register(ScanResult)
class ScanResultAdmin(ImportExportModelAdmin):
    resource_class = ScanResultResource
    list_display = ('scanner', 'total_stocks', 'total_new_stocks', 'message_sent', 'scan_duration', 'created_at')
    list_filter = ('scanner', 'created_at', 'message_sent')
    search_fields = ('scanner__name', 'error_message')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'stock_symbols', 'new_stock_symbols')
    fieldsets = (
        ('Basic Information', {
            'fields': ('scanner', 'created_at')
        }),
        ('Scan Results', {
            'fields': ('total_stocks', 'total_new_stocks', 'scan_duration', 'message_sent')
        }),
        ('Stock Data', {
            'fields': ('stocks', 'new_stocks', 'stock_symbols', 'new_stock_symbols'),
            'classes': ('collapse',)
        }),
        ('Error Information', {
            'fields': ('error_message',),
            'classes': ('collapse',)
        }),
    )

    def has_add_permission(self, request):
        return False  # Prevent manual creation of scan results 