from django.db import models
from django.contrib.auth.models import User

class Bot(models.Model):
    name = models.CharField(max_length=100, unique=True)
    token = models.CharField(max_length=100)
    chat_id = models.CharField(max_length=100)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class Scanner(models.Model):
    name = models.CharField(max_length=100)
    condition = models.TextField()
    bot = models.ForeignKey(Bot, on_delete=models.CASCADE, related_name='scanners')
    chat_id = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    scan_interval = models.IntegerField(default=150)  # in seconds
    last_run = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('name', 'bot')

    def __str__(self):
        return f"{self.bot.name} - {self.name}"

class ScanResult(models.Model):
    scanner = models.ForeignKey(Scanner, on_delete=models.CASCADE, related_name='results')
    stocks = models.JSONField()  # Stores the raw stock data
    total_stocks = models.IntegerField(default=0)  # Total number of stocks found
    new_stocks = models.JSONField(null=True, blank=True)  # Stores only the new stocks found
    total_new_stocks = models.IntegerField(default=0)  # Number of new stocks found
    message_sent = models.BooleanField(default=False)  # Whether notification was sent
    error_message = models.TextField(null=True, blank=True)  # Any error that occurred
    scan_duration = models.FloatField(null=True, blank=True)  # Time taken to run the scan in seconds
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['scanner', '-created_at']),
        ]

    def __str__(self):
        return f"{self.scanner.name} - {self.created_at} ({self.total_stocks} stocks)"

    @property
    def stock_symbols(self):
        """Return list of stock symbols from the results"""
        return [stock.get('nsecode', '') for stock in self.stocks.get('data', [])]

    @property
    def new_stock_symbols(self):
        """Return list of new stock symbols"""
        if self.new_stocks:
            return [stock.get('nsecode', '') for stock in self.new_stocks]
        return [] 