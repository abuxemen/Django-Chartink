from django.apps import AppConfig

class ChartinkBotsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chartink_bots'

    def ready(self):
        """Start the scanner thread when the app is ready"""
        # Avoid running this in manage.py commands
        import sys
        if 'runserver' in sys.argv:
            from .scanner_service import start_scanner_thread
            start_scanner_thread() 