from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView
from django.urls import reverse_lazy
import asyncio
from asgiref.sync import async_to_sync
from .models import Bot, Scanner, ScanResult
from .forms import BotForm, ScannerForm
from .services import ChartinkService
from telegram.error import TelegramError
from django.db.models import Count, Avg, Max, Min, Sum, Q
from django.utils import timezone
from datetime import timedelta

def scanner_counts(request):
    """Context processor to add scanner counts to all templates"""
    if request.user.is_authenticated:
        total_scanners = Scanner.objects.filter(bot__owner=request.user).count()
        return {
            'total_scanners': total_scanners
        }
    return {'total_scanners': 0}

class BotListView(LoginRequiredMixin, ListView):
    model = Bot
    template_name = 'chartink_bots/bot_list.html'
    context_object_name = 'bots'

    def get_queryset(self):
        return Bot.objects.filter(owner=self.request.user)

class BotCreateView(LoginRequiredMixin, CreateView):
    model = Bot
    form_class = BotForm
    template_name = 'chartink_bots/bot_form.html'
    success_url = reverse_lazy('bot-list')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class BotUpdateView(LoginRequiredMixin, UpdateView):
    model = Bot
    form_class = BotForm
    template_name = 'chartink_bots/bot_form.html'
    success_url = reverse_lazy('bot-list')

    def get_queryset(self):
        return Bot.objects.filter(owner=self.request.user)

class BotDeleteView(LoginRequiredMixin, DeleteView):
    model = Bot
    template_name = 'chartink_bots/bot_confirm_delete.html'
    success_url = reverse_lazy('bot-list')

    def get_queryset(self):
        return Bot.objects.filter(owner=self.request.user)

class ScannerListView(LoginRequiredMixin, ListView):
    model = Scanner
    template_name = 'chartink_bots/scanner_list.html'
    context_object_name = 'scanners'

    def get_queryset(self):
        bot_id = self.kwargs.get('bot_id')
        return Scanner.objects.filter(
            bot__owner=self.request.user,
            bot_id=bot_id
        ).select_related('bot')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        bot_id = self.kwargs.get('bot_id')
        context['bot'] = get_object_or_404(Bot, id=bot_id, owner=self.request.user)
        return context

class ScannerCreateView(LoginRequiredMixin, CreateView):
    model = Scanner
    form_class = ScannerForm
    template_name = 'chartink_bots/scanner_form.html'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        bot_id = self.kwargs.get('bot_id')
        kwargs['bot'] = get_object_or_404(Bot, id=bot_id, owner=self.request.user)
        return kwargs
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        bot_id = self.kwargs.get('bot_id')
        context['bot'] = get_object_or_404(Bot, id=bot_id, owner=self.request.user)
        return context
    
    def form_valid(self, form):
        form.instance.bot = get_object_or_404(Bot, id=self.kwargs['bot_id'], owner=self.request.user)
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse_lazy('scanner-list', kwargs={'bot_id': self.kwargs['bot_id']})

class ScannerUpdateView(LoginRequiredMixin, UpdateView):
    model = Scanner
    form_class = ScannerForm
    template_name = 'chartink_bots/scanner_form.html'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_queryset(self):
        return Scanner.objects.filter(bot__owner=self.request.user)
    
    def get_success_url(self):
        return reverse_lazy('scanner-list', kwargs={'bot_id': self.object.bot.id})

class ScannerDeleteView(LoginRequiredMixin, DeleteView):
    model = Scanner
    template_name = 'chartink_bots/scanner_confirm_delete.html'

    def get_queryset(self):
        return Scanner.objects.filter(bot__owner=self.request.user)
    
    def get_success_url(self):
        return reverse_lazy('scanner-list', kwargs={'bot_id': self.object.bot.id})

@login_required
def run_scanner(request, scanner_id):
    scanner = get_object_or_404(Scanner, id=scanner_id, bot__owner=request.user)
    service = ChartinkService(scanner.bot)
    
    async def process():
        try:
            # Ensure we're in a proper async context
            result = await service.process_scanner(scanner)
            # Use sync_to_async for any database operations if needed
            return True
        except Exception as e:
            return str(e)
    
    try:
        error = async_to_sync(process)()
        if error is True:
            messages.success(request, f'Scanner "{scanner.name}" has been triggered.')
        else:
            messages.error(request, f'Error running scanner: {error}')
    except Exception as e:
        messages.error(request, f'Error running scanner: {str(e)}')
    
    return redirect('scanner-list', bot_id=scanner.bot.id)

@login_required
def dashboard(request):
    bots = Bot.objects.filter(owner=request.user)
    scanners = Scanner.objects.filter(
        bot__owner=request.user
    ).select_related('bot').order_by('bot__name', 'name')
    recent_results = ScanResult.objects.filter(
        scanner__bot__owner=request.user
    ).select_related('scanner', 'scanner__bot').order_by('-created_at')[:10]
    
    context = {
        'bots': bots,
        'scanners': scanners,
        'recent_results': recent_results,
    }
    return render(request, 'chartink_bots/dashboard.html', context)

@login_required
def send_test_message(request, bot_id):
    bot = get_object_or_404(Bot, id=bot_id, owner=request.user)
    service = ChartinkService(bot)
    
    async def send_message():
        try:
            test_message = "🧪 Test Message\n\n"
            test_message += "This is a test message to verify your bot configuration.\n"
            test_message += f"Bot Name: {bot.name}\n"
            test_message += "If you received this message, your bot is working correctly! 🎉"
            
            await service.telegram_bot.send_message(chat_id=bot.chat_id, text=test_message)
            messages.success(request, 'Test message sent successfully!')
        except TelegramError as e:
            messages.error(request, f'Telegram error: {str(e)}')
        except Exception as e:
            messages.error(request, f'Error sending test message: {str(e)}')
    
    async_to_sync(send_message)()
    return redirect('bot-list')

@login_required
def scan_results(request, scanner_id=None):
    """View for detailed scan results with filtering and statistics"""
    # Base queryset
    results = ScanResult.objects.select_related('scanner', 'scanner__bot')
    
    # Filter by scanner if provided
    scanner = None
    if scanner_id:
        scanner = get_object_or_404(Scanner, id=scanner_id, bot__owner=request.user)
        results = results.filter(scanner=scanner)
    else:
        results = results.filter(scanner__bot__owner=request.user)
    
    # Get time range filter
    time_range = request.GET.get('time_range', '24h')
    if time_range:
        now = timezone.now()
        if time_range == '24h':
            results = results.filter(created_at__gte=now - timedelta(hours=24))
        elif time_range == '7d':
            results = results.filter(created_at__gte=now - timedelta(days=7))
        elif time_range == '30d':
            results = results.filter(created_at__gte=now - timedelta(days=30))
    
    # Get status filter
    status = request.GET.get('status')
    if status == 'success':
        results = results.filter(error_message__isnull=True)
    elif status == 'error':
        results = results.filter(error_message__isnull=False)
    elif status == 'new_stocks':
        results = results.filter(total_new_stocks__gt=0)
    
    # Calculate statistics
    total_count = results.count()
    if total_count > 0:
        stats = results.aggregate(
            total_scans=Count('id'),
            avg_stocks=Avg('total_stocks'),
            max_stocks=Max('total_stocks'),
            avg_duration=Avg('scan_duration'),
            success_rate=Count('id', filter=Q(error_message__isnull=True)) * 100.0 / Count('id'),
            total_new_stocks=Sum('total_new_stocks')
        )
    else:
        stats = {
            'total_scans': 0,
            'avg_stocks': 0,
            'max_stocks': 0,
            'avg_duration': 0,
            'success_rate': 0,
            'total_new_stocks': 0
        }
    
    # Get scanners for filter dropdown
    scanners = Scanner.objects.filter(bot__owner=request.user).select_related('bot')
    
    context = {
        'results': results[:1000],  # Limit to last 1000 results for performance
        'scanner': scanner,
        'scanners': scanners,
        'stats': stats,
        'time_range': time_range,
        'status': status,
    }
    
    return render(request, 'chartink_bots/scan_results.html', context)

@login_required
def toggle_bot(request, bot_id):
    """Toggle bot active status"""
    bot = get_object_or_404(Bot, id=bot_id, owner=request.user)
    bot.is_active = not bot.is_active
    bot.save()
    messages.success(request, f"Bot {'activated' if bot.is_active else 'deactivated'} successfully!")
    return redirect('bot-list')

@login_required
def toggle_scanner(request, scanner_id):
    """Toggle scanner active status"""
    scanner = get_object_or_404(Scanner, id=scanner_id, bot__owner=request.user)
    scanner.is_active = not scanner.is_active
    scanner.save()
    messages.success(request, f"Scanner {'activated' if scanner.is_active else 'deactivated'} successfully!")
    return redirect('scanner-list', bot_id=scanner.bot.id)

@login_required
def scanner_history(request, scanner_id):
    """View for detailed scanner history with statistics"""
    scanner = get_object_or_404(Scanner, id=scanner_id, bot__owner=request.user)
    
    # Get time range filter
    time_range = request.GET.get('time_range', '24h')
    results = ScanResult.objects.filter(scanner=scanner)
    
    if time_range:
        now = timezone.now()
        if time_range == '24h':
            results = results.filter(created_at__gte=now - timedelta(hours=24))
        elif time_range == '7d':
            results = results.filter(created_at__gte=now - timedelta(days=7))
        elif time_range == '30d':
            results = results.filter(created_at__gte=now - timedelta(days=30))
    
    # Calculate statistics
    total_count = results.count()
    if total_count > 0:
        stats = results.aggregate(
            total_scans=Count('id'),
            avg_stocks=Avg('total_stocks'),
            max_stocks=Max('total_stocks'),
            avg_duration=Avg('scan_duration'),
            success_rate=Count('id', filter=Q(error_message__isnull=True)) * 100.0 / Count('id'),
            total_new_stocks=Sum('total_new_stocks')
        )
    else:
        stats = {
            'total_scans': 0,
            'avg_stocks': 0,
            'max_stocks': 0,
            'avg_duration': 0,
            'success_rate': 0,
            'total_new_stocks': 0
        }
    
    context = {
        'scanner': scanner,
        'results': results[:1000],  # Limit to last 1000 results for performance
        'stats': stats,
        'time_range': time_range,
    }
    
    return render(request, 'chartink_bots/scanner_history.html', context) 