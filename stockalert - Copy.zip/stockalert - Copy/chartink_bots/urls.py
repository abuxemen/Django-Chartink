from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    
    # Bot URLs
    path('bots/', views.BotListView.as_view(), name='bot-list'),
    path('bots/add/', views.BotCreateView.as_view(), name='bot-create'),
    path('bots/<int:pk>/edit/', views.BotUpdateView.as_view(), name='bot-update'),
    path('bots/<int:pk>/delete/', views.BotDeleteView.as_view(), name='bot-delete'),
    path('bots/<int:bot_id>/test-message/', views.send_test_message, name='send-test-message'),
    path('bots/<int:bot_id>/toggle/', views.toggle_bot, name='bot-toggle'),
    
    # Scanner URLs
    path('bots/<int:bot_id>/scanners/', views.ScannerListView.as_view(), name='scanner-list'),
    path('bots/<int:bot_id>/scanners/add/', views.ScannerCreateView.as_view(), name='scanner-create'),
    path('scanners/<int:pk>/edit/', views.ScannerUpdateView.as_view(), name='scanner-update'),
    path('scanners/<int:pk>/delete/', views.ScannerDeleteView.as_view(), name='scanner-delete'),
    path('scanners/<int:scanner_id>/run/', views.run_scanner, name='scanner-run'),
    path('scanners/<int:scanner_id>/toggle/', views.toggle_scanner, name='scanner-toggle'),
    path('scanners/<int:scanner_id>/history/', views.scanner_history, name='scanner-history'),
    
    # Scan Results URLs
    path('results/', views.scan_results, name='scan-results'),
    path('results/<int:scanner_id>/', views.scan_results, name='scanner-results'),
] 