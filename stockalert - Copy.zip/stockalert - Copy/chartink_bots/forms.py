from django import forms
from .models import Bot, Scanner

class BotForm(forms.ModelForm):
    class Meta:
        model = Bot
        fields = ['name', 'token', 'chat_id']
        widgets = {
            'token': forms.PasswordInput(render_value=True),
        }
        help_texts = {
            'chat_id': 'The Telegram chat ID where messages will be sent',
        }

class ScannerForm(forms.ModelForm):
    class Meta:
        model = Scanner
        fields = ['name', 'condition', 'chat_id', 'scan_interval', 'is_active']
        widgets = {
            'condition': forms.Textarea(attrs={'rows': 4}),
            'chat_id': forms.TextInput(attrs={'placeholder': 'Leave empty to use bot\'s chat ID'}),
        }
        help_texts = {
            'chat_id': 'The Telegram chat ID where alerts will be sent (optional, defaults to bot\'s chat ID)',
            'scan_interval': 'Interval in seconds between scans',
            'condition': 'ChartInk condition for scanning stocks',
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        bot = kwargs.pop('bot', None)
        super().__init__(*args, **kwargs)
        if bot and not self.instance.pk:  # Only set default for new instances
            self.fields['chat_id'].initial = bot.chat_id 